/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include "peripheral/port/plib_port.h"


// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

int main ( void )
{
    /* Initialize all modules */
    SYS_Initialize( NULL );
    SYSTICK_TimerStart();
    GPIO_RLED_OutputEnable();
    GPIO_BLED_OutputEnable();
    GPIO_GLED_OutputEnable();
    while ( true )
    {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks();
        GPIO_RLED_Set();
        SYSTICK_DelayMs(1000);
        GPIO_GLED_Set();
        SYSTICK_DelayMs(1000);
        GPIO_BLED_Set();
        SYSTICK_DelayMs(1000);
        
        GPIO_RLED_Clear();
        SYSTICK_DelayMs(1000);
        GPIO_GLED_Clear();
        SYSTICK_DelayMs(1000);
        GPIO_BLED_Clear();
        SYSTICK_DelayMs(1000);
      }

    /* Execution should not come here during normal operation */
    return ( EXIT_FAILURE );
}


/*******************************************************************************
 End of File
*/

